After running `flutter create . --platforms=android` inside mobile/, edit android/app/src/main/AndroidManifest.xml and add these permissions directly under <manifest>:
<uses-permission android:name="android.permission.INTERNET"/>
<uses-permission android:name="android.permission.CAMERA"/>
The image_picker plugin handles Android photo picker/camera integration. Verify permissions and target SDK against your installed Flutter version.
