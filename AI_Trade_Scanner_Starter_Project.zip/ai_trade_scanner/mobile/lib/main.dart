import 'dart:convert';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter_markdown/flutter_markdown.dart';
import 'package:http/http.dart' as http;
import 'package:image_picker/image_picker.dart';

void main() => runApp(const TradeScannerApp());

class TradeScannerApp extends StatelessWidget {
  const TradeScannerApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
    debugShowCheckedModeBanner: false,
    title: 'AI Trade Scanner',
    theme: ThemeData.dark(useMaterial3: true).copyWith(
      scaffoldBackgroundColor: const Color(0xFF0B1020),
      colorScheme: const ColorScheme.dark(primary: Color(0xFF28D7A0), secondary: Color(0xFF6B8CFF)),
    ),
    home: const ScannerHome(),
  );
}

class ScannerHome extends StatefulWidget {
  const ScannerHome({super.key});
  @override
  State<ScannerHome> createState() => _ScannerHomeState();
}

class _ScannerHomeState extends State<ScannerHome> {
  final picker = ImagePicker();
  final api = TextEditingController(text: 'http://10.0.2.2:3000');
  final symbol = TextEditingController(text: 'BTCUSDT');
  final contextText = TextEditingController();
  String asset = 'crypto';
  String timeframe = '1h';
  File? chart;
  String result = 'अपना चार्ट चुनें और AI Analysis दबाएँ।';
  bool busy = false;

  Future<void> choose(ImageSource source) async {
    final file = await picker.pickImage(source: source, imageQuality: 90, maxWidth: 1800);
    if (file != null) setState(() { chart = File(file.path); result = 'चार्ट तैयार है।'; });
  }

  Future<void> analyze() async {
    if (chart == null) { setState(() => result = 'पहले कैमरा या गैलरी से चार्ट चुनें।'); return; }
    setState(() { busy = true; result = 'AI चार्ट का विश्लेषण कर रहा है…'; });
    try {
      final uri = Uri.parse('${api.text.trim()}/api/analyze-chart');
      final request = http.MultipartRequest('POST', uri)
        ..fields['asset'] = asset
        ..fields['symbol'] = symbol.text.trim()
        ..fields['timeframe'] = timeframe
        ..fields['extraContext'] = contextText.text.trim()
        ..files.add(await http.MultipartFile.fromPath('chart', chart!.path));
      final streamed = await request.send().timeout(const Duration(seconds: 90));
      final body = await streamed.stream.bytesToString();
      final json = jsonDecode(body);
      if (streamed.statusCode >= 400) throw Exception(json['error'] ?? 'Server error');
      setState(() => result = json['analysis'] ?? 'कोई परिणाम नहीं मिला।');
    } catch (e) {
      setState(() => result = 'त्रुटि: $e\n\nBackend URL और server status जाँचें।');
    } finally { setState(() => busy = false); }
  }

  @override
  void dispose() { api.dispose(); symbol.dispose(); contextText.dispose(); super.dispose(); }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('AI TRADE SCANNER'), actions: [
      IconButton(tooltip: 'Backend URL', icon: const Icon(Icons.settings), onPressed: () => showDialog(
        context: context, builder: (_) => AlertDialog(
          title: const Text('Backend URL'),
          content: TextField(controller: api, decoration: const InputDecoration(hintText: 'https://your-server.com')),
          actions: [TextButton(onPressed: () => Navigator.pop(context), child: const Text('Done'))],
        )))
    ]),
    body: ListView(padding: const EdgeInsets.all(16), children: [
      Container(
        padding: const EdgeInsets.all(18),
        decoration: BoxDecoration(gradient: const LinearGradient(colors: [Color(0xFF172A42), Color(0xFF18203A)]), borderRadius: BorderRadius.circular(20)),
        child: const Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text('SMART MARKET ANALYSIS', style: TextStyle(color: Color(0xFF28D7A0), letterSpacing: 1.4, fontWeight: FontWeight.bold)),
          SizedBox(height: 8), Text('Scan. Understand. Manage Risk.', style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
          SizedBox(height: 5), Text('Stocks + Crypto • AI Vision • Hindi Reports', style: TextStyle(color: Colors.white70))
        ]),
      ),
      const SizedBox(height: 18),
      Row(children: [
        Expanded(child: DropdownButtonFormField<String>(value: asset, decoration: const InputDecoration(labelText: 'Market'), items: const [
          DropdownMenuItem(value: 'crypto', child: Text('Crypto')),
          DropdownMenuItem(value: 'stock', child: Text('Stocks')),
        ], onChanged: (v) => setState(() => asset = v!))),
        const SizedBox(width: 12),
        Expanded(child: DropdownButtonFormField<String>(value: timeframe, decoration: const InputDecoration(labelText: 'Timeframe'), items: const [
          DropdownMenuItem(value: '5m', child: Text('5 min')),
          DropdownMenuItem(value: '15m', child: Text('15 min')),
          DropdownMenuItem(value: '1h', child: Text('1 hour')),
          DropdownMenuItem(value: '4h', child: Text('4 hours')),
          DropdownMenuItem(value: '1d', child: Text('1 day')),
        ], onChanged: (v) => setState(() => timeframe = v!))),
      ]),
      const SizedBox(height: 12),
      TextField(controller: symbol, decoration: const InputDecoration(labelText: 'Symbol', hintText: 'BTCUSDT / AAPL / RELIANCE')),
      const SizedBox(height: 14),
      if (chart != null) ClipRRect(borderRadius: BorderRadius.circular(14), child: Image.file(chart!, height: 190, fit: BoxFit.contain))
      else Container(height: 150, decoration: BoxDecoration(color: const Color(0xFF151D31), borderRadius: BorderRadius.circular(14)), child: const Center(child: Icon(Icons.candlestick_chart, size: 60, color: Colors.white38))),
      const SizedBox(height: 12),
      Row(children: [
        Expanded(child: OutlinedButton.icon(onPressed: busy ? null : () => choose(ImageSource.camera), icon: const Icon(Icons.camera_alt), label: const Text('Camera'))),
        const SizedBox(width: 10),
        Expanded(child: OutlinedButton.icon(onPressed: busy ? null : () => choose(ImageSource.gallery), icon: const Icon(Icons.photo_library), label: const Text('Gallery'))),
      ]),
      const SizedBox(height: 12),
      TextField(controller: contextText, maxLines: 2, decoration: const InputDecoration(labelText: 'Extra context (optional)', hintText: 'Exchange, indicator settings, or notes')),
      const SizedBox(height: 14),
      FilledButton.icon(onPressed: busy ? null : analyze, icon: busy ? const SizedBox(width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2)) : const Icon(Icons.auto_awesome), label: Text(busy ? 'Analyzing…' : 'AI CHART ANALYSIS')),
      const SizedBox(height: 18),
      const Text('ANALYSIS REPORT', style: TextStyle(color: Color(0xFF28D7A0), fontWeight: FontWeight.bold, letterSpacing: 1.2)),
      const SizedBox(height: 8),
      Container(padding: const EdgeInsets.all(16), decoration: BoxDecoration(color: const Color(0xFF151D31), borderRadius: BorderRadius.circular(16)), child: MarkdownBody(data: result, selectable: true)),
      const SizedBox(height: 16),
      const Text('Risk reminder: AI signals are uncertain and may be wrong. Verify market data and use your own risk controls. This app does not place trades.', style: TextStyle(color: Colors.white54, fontSize: 12)),
    ]),
  );
}
