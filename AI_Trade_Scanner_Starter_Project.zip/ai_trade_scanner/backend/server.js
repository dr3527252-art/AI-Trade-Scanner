import express from "express";
import cors from "cors";
import multer from "multer";
import dotenv from "dotenv";

dotenv.config();
const app = express();
const upload = multer({ storage: multer.memoryStorage(), limits: { fileSize: 8 * 1024 * 1024 } });

app.use(cors()); // Lock this to your app's backend origin in production.
app.use(express.json({ limit: "1mb" }));

const STRATEGY_KNOWLEDGE = `
Use general, non-proprietary technical-analysis concepts:
- market structure and trend; support/resistance; breakout and retest
- candlestick context (engulfing, pin bar, doji) only when clearly visible
- EMA/SMA, RSI, MACD, Bollinger Bands, volume and volatility
- risk/reward and position sizing; avoid signals when chart/data is unclear
The user listed these books as study references, but no book text is supplied:
"A Beginner's Guide To The Indian Stock Market",
"Technical Analysis Made Easy",
"The Only Technical Analysis Book You Will Ever Need",
"The Simplest Book For Technical Analysis".
Do not claim to quote or have read their full contents.
`;

app.get("/health", (_req, res) => res.json({ ok: true, service: "AI Trade Scanner" }));

app.post("/api/analyze-chart", upload.single("chart"), async (req, res) => {
  try {
    if (!process.env.OPENAI_API_KEY) return res.status(503).json({ error: "Backend OpenAI API key is not configured." });
    if (!req.file) return res.status(400).json({ error: "Chart image is required." });

    const asset = String(req.body.asset || "stock");
    const symbol = String(req.body.symbol || "Unknown");
    const timeframe = String(req.body.timeframe || "Unknown");
    const mime = req.file.mimetype;
    if (!["image/jpeg", "image/png", "image/webp"].includes(mime)) {
      return res.status(415).json({ error: "Use JPG, PNG, or WEBP chart images." });
    }
    const imageData = `data:${mime};base64,${req.file.buffer.toString("base64")}`;

    const apiResponse = await fetch("https://api.openai.com/v1/responses", {
      method: "POST",
      headers: {
        "Authorization": `Bearer ${process.env.OPENAI_API_KEY}`,
        "Content-Type": "application/json"
      },
      body: JSON.stringify({
        model: process.env.OPENAI_MODEL || "gpt-4.1",
        instructions: `You are a cautious technical-analysis assistant. Reply in Hindi. ${STRATEGY_KNOWLEDGE}
Analyze only what is visible. Never invent prices, indicators, volume, or candles. If exact price levels are unreadable, say so and use null.
Return a concise structured report with: asset, symbol, timeframe, signal (BUY/SELL/HOLD/INSUFFICIENT_DATA), confidence (0-100 only as subjective pattern confidence, not probability), trend, visible_patterns, support, resistance, entry, stop_loss, targets, risk_reward, reasons, invalidation, missing_data, and disclaimer.
A screenshot alone may be insufficient. Do not guarantee profit and do not tell the user to place a trade.`,
        input: [{
          role: "user",
          content: [
            { type: "input_text", text: `Analyze this ${asset} chart. Symbol: ${symbol}. Timeframe: ${timeframe}. ${req.body.extraContext || ""}` },
            { type: "input_image", image_url: imageData, detail: "high" }
          ]
        }]
      })
    });

    const data = await apiResponse.json();
    if (!apiResponse.ok) return res.status(apiResponse.status).json({ error: data.error?.message || "OpenAI request failed." });
    res.json({ analysis: data.output_text || "No text analysis returned.", model: process.env.OPENAI_MODEL || "gpt-4.1" });
  } catch (err) {
    res.status(500).json({ error: "Analysis failed.", detail: err.message });
  }
});

// Public Binance market candles for crypto. This is data retrieval, not an AI trade signal.
app.get("/api/market/candles", async (req, res) => {
  try {
    const asset = String(req.query.asset || "crypto");
    const symbol = String(req.query.symbol || "BTCUSDT").toUpperCase();
    const interval = String(req.query.interval || "1m");
    const limit = Math.min(Math.max(Number(req.query.limit || 100), 20), 500);
    if (asset !== "crypto") {
      return res.status(501).json({ error: "Stock candles need a licensed provider configured by the app operator." });
    }
    if (!/^[A-Z0-9]{5,20}$/.test(symbol)) return res.status(400).json({ error: "Invalid symbol." });
    const allowed = new Set(["1m","3m","5m","15m","30m","1h","2h","4h","1d","1w"]);
    if (!allowed.has(interval)) return res.status(400).json({ error: "Unsupported interval." });
    const url = new URL("https://api.binance.com/api/v3/klines");
    url.search = new URLSearchParams({ symbol, interval, limit }).toString();
    const upstream = await fetch(url);
    const rows = await upstream.json();
    if (!upstream.ok) return res.status(upstream.status).json({ error: "Market data provider error.", detail: rows });
    res.json({ provider: "Binance", symbol, interval, candles: rows.map(r => ({
      time: r[0], open: Number(r[1]), high: Number(r[2]), low: Number(r[3]),
      close: Number(r[4]), volume: Number(r[5])
    }))});
  } catch (err) {
    res.status(502).json({ error: "Market data unavailable.", detail: err.message });
  }
});

const port = Number(process.env.PORT || 3000);
app.listen(port, () => console.log(`AI Trade Scanner backend listening on ${port}`));
