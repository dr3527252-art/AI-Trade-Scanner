# AI Trade Scanner — starter project

This is a starter source project for an Android app that scans chart screenshots and requests AI explanations.
It is **not a compiled APK**. Build it with Flutter/Android SDK using the steps below.

## Included
- Flutter Android app UI
- Camera/gallery chart image selection
- Backend proxy for OpenAI Responses API image analysis
- Basic live-market candle endpoint for Binance crypto
- Stock live-data adapter placeholder (requires a market-data provider)
- Hindi-first analysis prompt with BUY / SELL / HOLD, entry, stop-loss, targets, and uncertainty
- Strategy concepts checklist inspired by the four book titles supplied by the user (not copied book text)

## Security
Never put your OpenAI API key inside the Android app. Put it only in `backend/.env` on a private server.
The Flutter app calls your backend. Restrict the backend with authentication/rate limits before public release.

## 1. Backend
```bash
cd backend
cp .env.example .env
# Add your OpenAI key and choose a vision-capable model available to your API account
npm install
npm start
```
Deploy the backend on HTTPS. Set `OPENAI_MODEL` to a vision-capable model available in your OpenAI project.
For local Android emulator use `http://10.0.2.2:3000`; for a physical phone use your computer/server LAN IP or deployed HTTPS URL.

## 2. Flutter app
Install Flutter SDK and Android Studio (Android SDK), then:
```bash
cd mobile
flutter create . --platforms=android
flutter pub get
flutter run
```
To build:
```bash
flutter build apk --release
```
The APK will be at `mobile/build/app/outputs/flutter-apk/app-release.apk`.

## 3. Live market data
- Crypto: `/api/market/candles?asset=crypto&symbol=BTCUSDT&interval=1m&limit=100` uses Binance public klines.
- Stocks: configure a licensed stock-data provider in `backend/server.js` before enabling live stock signals. The starter deliberately does not fabricate stock prices.
- A chart screenshot alone cannot reliably reveal exact price/time/volume data. For stronger analysis, send OHLCV candles from a trusted provider alongside the screenshot.

## 4. Book concepts
The app prompt references general concepts: trend, support/resistance, candlesticks, moving averages, RSI, MACD, Bollinger Bands, volume, risk/reward, and position sizing. It does not reproduce the books:
- A Beginner's Guide To The Indian Stock Market
- Technical Analysis Made Easy
- The Only Technical Analysis Book You Will Ever Need
- The Simplest Book For Technical Analysis

## Important
AI outputs are educational analysis, not guaranteed predictions or personalized financial advice. Never auto-place trades. Verify data, fees, liquidity, and risk independently.
